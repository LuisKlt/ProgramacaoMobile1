class Post {
  int codigo;
  String nome;

  Post({
    required this.codigo,
    required this.nome,
  });

  factory Post.fromMap(Map<String, dynamic> mapa) {
    return Post(
      codigo: mapa['codigo'],
      nome: mapa['nome'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'codigo': codigo,
      'nome': nome,
    };
  }
}
